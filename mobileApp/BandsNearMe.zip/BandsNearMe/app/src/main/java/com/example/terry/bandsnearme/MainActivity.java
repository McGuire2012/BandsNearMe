package com.example.terry.bandsnearme;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        }

    public void clickLoginCreateAccount(View view){
        Intent intent = new Intent(this, LoginCreateAccountActivity.class);
        startActivity(intent);
    }

    public void clickMaps(View view){
        Intent intent = new Intent(this, MapsActivity.class);
        startActivity(intent);
    }

    public void clickIndividualUser(View view){
        Intent intent = new Intent(this, IndividualUserActivity.class);
        startActivity(intent);
    }

    public void clickBand(View view){
        Intent intent = new Intent(this, BandActivity.class);
        startActivity(intent);
    }

    public void clickVenue(View view){
        Intent intent = new Intent(this, VenueActivity.class);
        startActivity(intent);
    }
}
